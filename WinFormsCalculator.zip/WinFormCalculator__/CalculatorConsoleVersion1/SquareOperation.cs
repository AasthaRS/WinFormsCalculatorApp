﻿
namespace Grapecity.TraineeAssignment.Calculator
{
    /// <summary>
    /// 'SquareOperation' class is derived from an abstract class
    /// named 'CalculatorOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class SquareOperation : CalculatorOperation
    {
        /// <summary>
        /// Caculates the square of the number.
        /// </summary>
        /// <param name="operands">Value on which operation has to be performed</param>
        /// <returns>Decimal type result</returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return operands[0] * operands[0];
        }
    }
}
