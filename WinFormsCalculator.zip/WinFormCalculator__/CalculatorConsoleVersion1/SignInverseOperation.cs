﻿namespace Grapecity.TraineeAssignment.Calculator
{
    /// <summary>
    /// 'SignInverseOperation' class is derived from an abstract class
    /// named 'CalculatorOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class SignInverseOperation : CalculatorOperation
    {
        /// <summary>
        /// Changes the sign of the number.
        /// </summary>
        /// <param name="operands">Value on which operation has to be performed</param>
        /// <returns>Decimal type result</returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return operands[0] * (-1);
        }
    }
}
