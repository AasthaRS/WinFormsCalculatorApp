﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'NaturalLogOperation' class is derived from an abstract class
    /// named 'LogarithmicOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class NaturalLogOperation : LogarithmicOperation
    {

        /// <summary>
        /// Calculates log base e of value.
        /// </summary>
        /// <param name="operands">Value on which operation has to be performed </param>
        /// <returns> Decimal type result </returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return (decimal)Math.Log(Decimal.ToDouble(operands[0]));
        }
    }
}
