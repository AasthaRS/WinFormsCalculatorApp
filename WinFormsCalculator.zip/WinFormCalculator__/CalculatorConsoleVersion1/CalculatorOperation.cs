﻿namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'CalculatorOperation' class is an abstract base 
    /// of Calculator Application.It contains an abstract
    /// function named 'PerformOperation'. This function will
    /// be defined in the classes derived from 'CalculatorOperation'
    /// class. 
    /// </summary>
    public abstract class CalculatorOperation
    {

        /// <summary>
        /// Abstract function to carry out the calculation.
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed </param>
        /// <returns> Decimal type result </returns>
        public abstract decimal PerformOperation(decimal[] operands);

    }
}