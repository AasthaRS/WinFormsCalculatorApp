﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'StandardLogOperation' class is derived from an abstract class
    /// named 'LogarithmicOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class StandardLogOperation : LogarithmicOperation
    {

        /// <summary>
        /// Calculates log base 10 of the value
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed </param>
        /// <returns> Decimal type result </returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return (decimal)Math.Log10(Decimal.ToDouble(operands[0]));
        }
        
    }
}
