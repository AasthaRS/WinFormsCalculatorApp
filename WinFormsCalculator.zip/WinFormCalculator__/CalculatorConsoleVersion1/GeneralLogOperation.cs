﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'GeneralLogOperation' class is derived from an abstract class
    /// named 'LogarithmicOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class GeneralLogOperation : LogarithmicOperation
    {

        /// <summary>
        /// Calculates log of value on base passed as parameter.
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed, Base for log function </param>
        /// <returns> Decimal type result </returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return (decimal)Math.Log(Decimal.ToDouble(operands[0]), Decimal.ToDouble(operands[1]));
        }
    }
}
