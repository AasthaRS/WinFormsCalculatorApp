﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'OperatorAlreadyExistsException' is a custom expection class
    /// that overrides 'Message' property of Exception class.
    /// </summary>
    public class OperatorAlreadyExistsException : Exception
    {
        public override string Message
        {
            get
            {
                return ExceptionStringResource.OperatorAlreadyExistsExceptionMessage;
            }
        }
    }
}
