﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'SineOperation' class is derived from an abstract class
    /// named 'TrigonometricOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class SineOperation : TrigonometricOperation
    {

        /// <summary>
        /// Calculates sine of the value passed as a parameter.
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed </param>
        /// <returns> decimal type calculated result </returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return (decimal)Math.Sin(Decimal.ToDouble(operands[0]));
        }
    }
}
