﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'SecantOperation' class is derived from an abstract class
    /// named 'TrigonometricOperation' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class SecantOperation : TrigonometricOperation
    {

        /// <summary>
        /// Calculates secant of the value passed as a parameter.
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed </param>
        /// <returns> decimal type calculated result </returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return 1/((decimal)Math.Cos(Decimal.ToDouble(operands[0])));
        }
    }
}
