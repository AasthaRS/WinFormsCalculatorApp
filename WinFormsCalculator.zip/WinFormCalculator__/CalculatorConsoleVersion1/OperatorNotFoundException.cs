﻿namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'OperatorNotFoundException' is a custom expection class
    /// that overrides 'Message' property of Exception class.
    /// </summary>
    public class OperatorNotFoundException : Exception
    {
        public override string Message
        {
            get
            {
                return ExceptionStringResource.OperatorNotFoundExceptionMessage;
            }
        }
    }
}
