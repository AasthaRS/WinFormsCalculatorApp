﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'CotangentOperation' class is derived from an abstract class
    /// named 'TrigonometricOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class CotangentOperation : TrigonometricOperation
    {

        /// <summary>
        /// Calculates cotangent of the value passed as a parameter.
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed </param>
        /// <returns> Decimal type result </returns>
        public override decimal PerformOperation(decimal[] operands)
        {
            return 1/((decimal)Math.Tan(Decimal.ToDouble(operands[0])));
        }
    }
}
