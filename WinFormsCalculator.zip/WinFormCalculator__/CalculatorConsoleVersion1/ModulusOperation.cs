﻿namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'ModulusOperation' class is derived from an abstract class
    /// named 'CalculatorOperations' and it contains defination of the
    /// abstract function of its base class.
    /// </summary>
    public class ModulusOperation : CalculatorOperation
    {

        /// <summary>
        /// Calculates modulus of the values passed as parameter.
        /// </summary>
        /// <param name="operands"> Value on which operation has to be performed </param>
        /// <returns> Decimal type result </returns>
        public override decimal PerformOperation(decimal[] operands)
        { 
            decimal result = operands[0];
            for (int index = 1; index < operands.Length; index++)
            {
                result %= operands[index];
            }
            return result;
        }
    }
}
