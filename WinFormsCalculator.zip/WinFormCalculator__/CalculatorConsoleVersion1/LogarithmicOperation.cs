﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'LogarithmicOperation' class is an abstract class from 
    /// another abstract class named 'CalculatorOperations'.
    /// </summary>
    public abstract class LogarithmicOperation : CalculatorOperation
    {
    }
}
