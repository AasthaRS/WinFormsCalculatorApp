﻿namespace Grapecity.TraineeAssignment.Calculator
{

    /// <summary>
    /// 'OperationsManager' class manages the overall functioning of
    /// pre-defined and user-defined operations.
    /// </summary>
    public class OperationsManager
    {

        /*
         * 'operatorOperationPair' is a dictionary for storing keys-value pairs corresponding to
         * the instances of 'CalculatorOperation' subclasses.
         */

        private Dictionary<string, CalculatorOperation> _operatorOperationPair = new Dictionary<string, CalculatorOperation>();

        /* 
         * Constructor to add operations and instances of CalculatorOperation subclasses
         * as key-value pairs.
         */ 

        public OperationsManager()
        {
            _operatorOperationPair.Add("+", new AdditionOperation());
            _operatorOperationPair.Add("-", new SubtractionOperation());
            _operatorOperationPair.Add("*", new MultiplicationOperation());
            _operatorOperationPair.Add("/", new DivisionOperation());
            _operatorOperationPair.Add("%", new ModulusOperation());
            _operatorOperationPair.Add("sin", new SineOperation());
            _operatorOperationPair.Add("cos", new CosineOperation());
            _operatorOperationPair.Add("tan", new TangentOperation());
            _operatorOperationPair.Add("cot", new CotangentOperation());
            _operatorOperationPair.Add("sec", new SecantOperation());
            _operatorOperationPair.Add("cosec", new CosecantOperation());
            _operatorOperationPair.Add("loge", new NaturalLogOperation());
            _operatorOperationPair.Add("log10", new StandardLogOperation());
            _operatorOperationPair.Add("logb", new GeneralLogOperation());
            _operatorOperationPair.Add("+/-", new SignInverseOperation());
            _operatorOperationPair.Add("x^2", new SquareOperation());
            _operatorOperationPair.Add("1/x", new ReciprocalOperation());
        }        

        /*
         * GetResult() returns calculated result for operators already present
         * in class library.
         */

        public decimal GetResult(decimal[] operands, string operation)
        {
            if (_operatorOperationPair.ContainsKey(operation))
            {
                return _operatorOperationPair[operation].PerformOperation(operands);
            }
            else
            {
                throw new OperatorNotFoundException();
            }
            
        }

        /*
         * If operator to be added is not in the dictionary, AddNewOperator()
         * adds its instance in the dictionary.
         */

        public void AddNewOperation(CalculatorOperation newOperationInstance, string newOperator)
        {
            if (_operatorOperationPair.ContainsKey(newOperator) == false)
            {
                _operatorOperationPair.Add(newOperator, newOperationInstance);
            }
            else
            {
                throw new OperatorAlreadyExistsException();
            }
        }
    }
}
