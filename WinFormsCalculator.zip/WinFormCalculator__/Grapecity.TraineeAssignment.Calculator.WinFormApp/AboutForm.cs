﻿using Grapecity.TraineeAssignment.UserControlWinform;

namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        private void OnNewLanguageSelected(object sender, LanguageSelectedChangedEventArgs eventArgs)
        {
            this._languageLabel.Text = eventArgs.SelectedLanguage.ToString();
        }
    }
}
