﻿using C1.Win.Input;

namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    public partial class CalculatorForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        ///  Required method for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            // 
            // Form1
            // 
            this.Size = new System.Drawing.Size(380, 520);
            this.Controls.Add(this._tableLayoutPanelCalculator);
            this.Name = "CalculatorForm";
            this.Text = Resources.StringResource.FormTitleText;
            this.MinimumSize = this.Size;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen; 
        }

    }
}