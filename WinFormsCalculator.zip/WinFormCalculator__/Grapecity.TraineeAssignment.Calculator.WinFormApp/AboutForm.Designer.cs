﻿namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._aboutFormContent = new C1.Win.Input.C1Label();
            this._languagePickerUserControl1 = new Grapecity.TraineeAssignment.UserControlWinform.LanguagePickerUserControl();
            this._languageLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._aboutFormContent)).BeginInit();
            this.SuspendLayout();
            // 
            // aboutFormContent
            // 
            this._aboutFormContent.AutoSize = true;
            this._aboutFormContent.Location = new System.Drawing.Point(12, 12);
            this._aboutFormContent.Name = "aboutFormContent";
            this._aboutFormContent.Size = new System.Drawing.Size(282, 30);
            this._aboutFormContent.TabIndex = 0;
            this._aboutFormContent.Text = global::Grapecity.TraineeAssignment.Calculator.WinFormApp.Resources.StringResource.AboutMenuFormContent;
            // 
            // _languagePickerUserControl1
            // 
            this._languagePickerUserControl1.AutoSize = true;
            this._languagePickerUserControl1.Location = new System.Drawing.Point(2, 66);
            this._languagePickerUserControl1.Name = "languagePickerUserControl1";
            this._languagePickerUserControl1.Size = new System.Drawing.Size(317, 122);
            this._languagePickerUserControl1.TabIndex = 1;
            this._languagePickerUserControl1.LanguageChanged += OnNewLanguageSelected;

            // 
            // _languageLabel
            // 
            this._languageLabel.AutoSize = true;
            this._languageLabel.Location = new System.Drawing.Point(108, 226);
            this._languageLabel.Name = "_languageLabel";
            this._languageLabel.Size = new System.Drawing.Size(59, 15);
            this._languageLabel.TabIndex = 2;
            this._languageLabel.Text = "Language";
            // 
            // AboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 250);
            this.Controls.Add(this._languageLabel);
            this.Controls.Add(this._languagePickerUserControl1);
            this.Controls.Add(this._aboutFormContent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AboutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About";
            ((System.ComponentModel.ISupportInitialize)(this._aboutFormContent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private C1.Win.Input.C1Label _aboutFormContent;
        private UserControlWinform.LanguagePickerUserControl _languagePickerUserControl1;
        private Label _languageLabel;
    }


}