﻿namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    /// <summary>
    /// 
    /// 'ToolTipLayout' class contains the following properties:
    ///     
    ///     ToolTipFunctionality : To store the functionality to be displayed on tooltip.
    ///     ToolTipUsage : To store the usage to be displayed on tooltip.
    ///     ToolTipKeyboardEquivalent : To store the keyboard equivalent to be displayed on tooltip
    ///     
    /// </summary>
    public class ToolTipLayout
    {
        public string ToolTipFunctionality { get; init; }
        public string ToolTipUsage { get; init; }
        public string ToolTipKeyboardEquivalent { get; init; }
    }
}
