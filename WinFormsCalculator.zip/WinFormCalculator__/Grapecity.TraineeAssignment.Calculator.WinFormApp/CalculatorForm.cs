using C1.Win.Input;
using C1.Win.Command;

namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    public partial class CalculatorForm : Form
    {
        private TableLayoutPanel _tableLayoutPanelCalculator;
        private TableLayoutPanel _tableLayoutPanelKeypad;
        private C1Button _buttonZero;
        private C1Button _buttonOne;
        private C1Button _buttonTwo;
        private C1Button _buttonThree;
        private C1Button _buttonFour;
        private C1Button _buttonFive;
        private C1Button _buttonSix;
        private C1Button _buttonSeven;
        private C1Button _buttonEight;
        private C1Button _buttonNine;
        private C1Button _buttonDecimal;
        private C1Button _buttonSign;
        private C1Button _buttonAdd;
        private C1Button _buttonSubtract;
        private C1Button _buttonMultiply;
        private C1Button _buttonDivide;
        private C1Button _buttonEquate;
        private C1Button _buttonPercentage;
        private C1SplitButton _splitButtonTrigonometricFunction;
        private SplitButtonItem _buttonItemSin;
        private SplitButtonItem _buttonItemCos;
        private SplitButtonItem _buttonItemTan;
        private SplitButtonItem _buttonItemCot;
        private SplitButtonItem _buttonItemSec;
        private SplitButtonItem _buttonItemCosec;
        private C1SplitButton _splitButtonLogarithmic;
        private C1Button _buttonBackspace;
        private C1Button _buttonCancel;
        private C1Button _buttonCancelEntry;
        private C1Button _buttonMemoryStore;
        private C1Button _buttonMemoryAdd;
        private C1Button _buttonMemoryDelete;
        private C1Button _buttonMemoryRead;
        private C1Button _buttonMemoryClear;
        private C1Button _buttonSquare;
        private C1Button _buttonReciprocal;
        private FlowLayoutPanel _flowLayoutSplitButtonsPanel;
        private SplitButtonItem _buttonItemLoge;
        private SplitButtonItem _buttonItemLog10;
        private C1Label _displayLabel;
        private C1TextBox _displayTextBox;
        private C1MainMenu _mainMenu;
        private C1CommandMenu _commandEdit;
        private C1CommandMenu _commandExit;
        private C1CommandMenu _commandHelp;
        private C1Command _commandCopy;
        private C1Command _commandPaste;
        private C1Command _commandAbout;
        private ToolTip _controlToolTip;
        private CalculatorController _controller;
        private Dictionary<C1Button, ButtonLayout> _buttonDictionary;
        private Dictionary<ButtonTypes, ToolTipLayout> _toolTipDictionary;
        private Dictionary<SplitButtonItem, SplitButtonItemLayout> _splitButtonItemDictionary;

        /// <summary>
        /// Enumeration to store types of buttons.
        /// </summary>
        public enum ButtonTypes
        {
            Numeric = 1,
            Decimal = 2,
            UnaryOperator = 3,
            BinaryOperator = 4,
            MemoryOperation = 5,
            Backspace = 6,
            Equate = 7,
            ClearDisplay = 8,
        }

        // Constructor to perform required initialization.
        public CalculatorForm()
        {
            _controller = new CalculatorController();
            _buttonDictionary = new Dictionary<C1Button, ButtonLayout>();
            _toolTipDictionary = new Dictionary<ButtonTypes, ToolTipLayout>();
            _splitButtonItemDictionary = new Dictionary<SplitButtonItem, SplitButtonItemLayout>();

            this._tableLayoutPanelCalculator = new TableLayoutPanel();
            this._tableLayoutPanelKeypad = new TableLayoutPanel();
            this._buttonOne = new C1Button();
            this._buttonTwo = new C1Button();
            this._buttonThree = new C1Button();
            this._buttonFour = new C1Button();
            this._buttonFive = new C1Button();
            this._buttonSix = new C1Button();
            this._buttonSeven = new C1Button();
            this._buttonEight = new C1Button();
            this._buttonNine = new C1Button();
            this._buttonZero = new C1Button();
            this._buttonDecimal = new C1Button();
            this._buttonSign = new C1Button();
            this._buttonAdd = new C1Button();
            this._buttonSubtract = new C1Button();
            this._buttonMultiply = new C1Button();
            this._buttonDivide = new C1Button();
            this._buttonEquate = new C1Button();
            this._buttonPercentage = new C1Button();
            this._splitButtonTrigonometricFunction = new C1SplitButton();
            this._buttonItemSin = new SplitButtonItem();
            this._buttonItemCos = new SplitButtonItem();
            this._buttonItemTan = new SplitButtonItem();
            this._buttonItemCot = new SplitButtonItem();
            this._buttonItemCosec = new SplitButtonItem();
            this._buttonItemSec = new SplitButtonItem();
            this._splitButtonLogarithmic = new C1SplitButton();
            this._buttonItemLoge = new SplitButtonItem();
            this._buttonItemLog10 = new SplitButtonItem();
            this._buttonBackspace = new C1Button();
            this._buttonCancelEntry = new C1Button();
            this._buttonCancel = new C1Button();
            this._buttonMemoryAdd = new C1Button();
            this._buttonMemoryDelete = new C1Button();
            this._buttonMemoryRead = new C1Button();
            this._buttonMemoryStore = new C1Button();
            this._buttonMemoryClear = new C1Button();
            this._buttonSquare = new C1Button();
            this._buttonReciprocal = new C1Button();
            this._flowLayoutSplitButtonsPanel = new FlowLayoutPanel();
            this._displayLabel = new C1Label();
            this._displayTextBox = new C1TextBox();
            this._mainMenu = new C1MainMenu();
            this._commandEdit = new C1CommandMenu();
            this._commandExit = new C1CommandMenu();   
            this._commandHelp = new C1CommandMenu();
            this._commandAbout = new C1CommandMenu();
            this._controlToolTip = new ToolTip();

            this._controlToolTip.ShowAlways = false;

            InitializeComponent();

            this.BuildToolTipDictionary();
            this.BuildButtonDictionary();
            this.BuildSplitButtonItemDictionary();
            this.CreateBasicLayout();
            this.CreateKeypad();
            this.CreateDisplay();
            this.CreateMenuStrip();
        }

        #region Dictionary Creation

        /// <summary>
        /// Function to add the buttons and their related information as key-value pairs in the dictionary.
        /// </summary>
        private void BuildButtonDictionary()
        {
            _buttonDictionary.Add(this._buttonZero, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonZeroContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonOne, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonOneContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonTwo, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonTwoContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonThree, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonThreeContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonFour, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonFourContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonFive, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonFiveContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonSix, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonSixContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonSeven, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonSevenContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonEight, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonEightContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonNine, new ButtonLayout(_toolTipDictionary[ButtonTypes.Numeric]) { ButtonContent = Resources.StringResource.ButtonNineContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnNumericButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonDecimal, new ButtonLayout(_toolTipDictionary[ButtonTypes.Decimal]){ ButtonContent = Resources.StringResource.ButtonDecimalContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnDecimalButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonAdd, new ButtonLayout(_toolTipDictionary[ButtonTypes.BinaryOperator]) { ButtonContent = Resources.StringResource.ButtonAddContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnBinaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonSubtract, new ButtonLayout(_toolTipDictionary[ButtonTypes.BinaryOperator]) { ButtonContent = Resources.StringResource.ButtonSubtractContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnBinaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonMultiply, new ButtonLayout(_toolTipDictionary[ButtonTypes.BinaryOperator]) { ButtonContent = Resources.StringResource.ButtonMultiplyContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnBinaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonDivide, new ButtonLayout(_toolTipDictionary[ButtonTypes.BinaryOperator]) { ButtonContent = Resources.StringResource.ButtonDivideContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnBinaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonPercentage, new ButtonLayout(_toolTipDictionary[ButtonTypes.BinaryOperator]) { ButtonContent = Resources.StringResource.ButtonPercentageContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnBinaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonCancel, new ButtonLayout(_toolTipDictionary[ButtonTypes.ClearDisplay]) { ButtonContent = Resources.StringResource.ButtonCancelContent, ButtonFontSize = 9F, ButtonClickEventHandler = OnClearDisplayButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonCancelEntry, new ButtonLayout(_toolTipDictionary[ButtonTypes.ClearDisplay]) { ButtonContent = Resources.StringResource.ButtonCancelEntryContent, ButtonFontSize = 9F, ButtonClickEventHandler = OnClearDisplayButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonBackspace, new ButtonLayout(_toolTipDictionary[ButtonTypes.Backspace]) { ButtonContent = Resources.StringResource.ButtonBackspaceContent, ButtonFontSize = 9F, ButtonClickEventHandler = OnBackspaceButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonSign, new ButtonLayout(_toolTipDictionary[ButtonTypes.UnaryOperator]) { ButtonContent = Resources.StringResource.ButtonSignContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnUnaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonSquare, new ButtonLayout(_toolTipDictionary[ButtonTypes.UnaryOperator]) { ButtonContent = Resources.StringResource.ButtonSquareContent, ButtonFontSize = 12F, ButtonClickEventHandler = OnUnaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonReciprocal, new ButtonLayout(_toolTipDictionary[ButtonTypes.UnaryOperator]) { ButtonContent = Resources.StringResource.ButtonReciprocalContent, ButtonFontSize = 12F, ButtonClickEventHandler = OnUnaryOperatorButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonEquate, new ButtonLayout(_toolTipDictionary[ButtonTypes.Equate]) { ButtonContent = Resources.StringResource.ButtonEquateContent, ButtonFontSize = 14F, ButtonClickEventHandler = OnEquateButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick } );
            _buttonDictionary.Add(this._buttonMemoryStore, new ButtonLayout(_toolTipDictionary[ButtonTypes.MemoryOperation]) { ButtonContent = Resources.StringResource.ButtonMemoryStoreContent, ButtonFontSize = 12F, ButtonClickEventHandler = OnMemoryButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonMemoryRead, new ButtonLayout(_toolTipDictionary[ButtonTypes.MemoryOperation]) { ButtonContent = Resources.StringResource.ButtonMemoryReadContent, ButtonFontSize = 12F, ButtonClickEventHandler = OnMemoryButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick } );
            _buttonDictionary.Add(this._buttonMemoryAdd, new ButtonLayout(_toolTipDictionary[ButtonTypes.MemoryOperation]) { ButtonContent = Resources.StringResource.ButtonMemoryAddContent, ButtonFontSize = 12F, ButtonClickEventHandler = OnMemoryButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonMemoryDelete, new ButtonLayout(_toolTipDictionary[ButtonTypes.MemoryOperation]) { ButtonContent = Resources.StringResource.ButtonMemoryDeleteContent, ButtonFontSize = 12F, ButtonClickEventHandler = OnMemoryButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
            _buttonDictionary.Add(this._buttonMemoryClear, new ButtonLayout(_toolTipDictionary[ButtonTypes.MemoryOperation]) { ButtonContent = Resources.StringResource.ButtonMemoryClearContent, ButtonFontSize = 9F, ButtonClickEventHandler = OnMemoryButtonClick, ButtonMouseRightClickEventHandler = OnControlsRightMouseButtonClick });
        }

        /// <summary>
        /// Function to add the button types and their related tooltip information as key-value pairs in the dictionary.
        /// </summary>
        private void BuildToolTipDictionary()
        {
            _toolTipDictionary.Add(ButtonTypes.Numeric, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipNumericButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipNumericButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipNumericButtonKeyboardEquivalentContent });
            _toolTipDictionary.Add(ButtonTypes.Decimal, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipDecimalButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipDecimalButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipDecimalButtonKeyboardEquivalentContent });
            _toolTipDictionary.Add(ButtonTypes.UnaryOperator, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipUnaryOperatorButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipUnaryOperatorButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipUnaryOperatorButtonKeyboardEquivalentContent });
            _toolTipDictionary.Add(ButtonTypes.BinaryOperator, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipBinaryOperatorButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipBinaryOperatorButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipBinaryOperatorButtonKeyboardEquivalentContent });
            _toolTipDictionary.Add(ButtonTypes.MemoryOperation, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipMemoryOperationButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipMemoryOperationButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipMemoryOperationButtonKeyboardEquivalentContent });
            _toolTipDictionary.Add(ButtonTypes.Backspace, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipBackspaceButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipBackspaceButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipBackspaceButtonKeyboardEquivalentContent});
            _toolTipDictionary.Add(ButtonTypes.Equate, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipEquateButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipEquateButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipEquateButtonKeyboardEquivalentContent });
            _toolTipDictionary.Add(ButtonTypes.ClearDisplay, new ToolTipLayout() { ToolTipFunctionality = Resources.StringResource.TooltipClearDisplayButtonFunctionalityContent, ToolTipUsage = Resources.StringResource.TooltipClearDisplayButtonUsageContent, ToolTipKeyboardEquivalent = Resources.StringResource.TooltipClearDisplayButtonKeyboardEquivalentContent });
        }

        /// <summary>
        /// Function to add the split button items and their related information as key-value pairs in the dictionary.
        /// </summary>
        private void BuildSplitButtonItemDictionary()
        {
            _splitButtonItemDictionary.Add(this._buttonItemSin, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemSinContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemCos, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemCosContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemTan, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemTanContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemCot, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemCotContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemSec, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemSecContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemCosec, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemCosecContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemLoge, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemLogeContent, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
            _splitButtonItemDictionary.Add(this._buttonItemLog10, new SplitButtonItemLayout() { SplitButtonItemContent = Resources.StringResource.ButtonItemLog10Content, SplitButtonItemEventHandler = OnUnaryOperatorSplitButtonItemClick });
        }

        #endregion

        #region Display and Keypad control events

        /// <summary>
        /// Handles keyboard inputs in the user input textbox area. 
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="keyPressEventArgs">Hold event specific message</param>
        private void OnDisplayTextBoxKeyPress(object sender, KeyPressEventArgs keyPressEventArgs)
        {
            keyPressEventArgs.Handled = _controller.HandleKeyInputForDisplayTextbox((sender as C1TextBox).Text, keyPressEventArgs);
        }

        /// <summary>
        /// Handles the event when a user enters the TextBox area.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnDisplayTextBoxEnter(object sender, EventArgs eventArgs)
        {
            if (_displayTextBox.Text == Resources.StringResource.TextboxInitialContent)
            {
                _displayTextBox.Text = String.Empty;
            }
        }

        /// <summary>
        /// Handles the event when a user leaves the TextBox area.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnDisplayTextBoxLeave(object sender, EventArgs eventArgs)
        {
            if (_displayTextBox.Text == String.Empty)
            {
                _displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
            }
        }

        /// <summary>
        /// Adds the numeric button clicked to the display, when button is clicked.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnNumericButtonClick(object sender, EventArgs eventArgs)
        {
            this._displayTextBox.Text = _controller.AddNumberToDisplay(_displayTextBox.Text, (sender as C1Button).Tag.ToString());
        }

        /// <summary>
        /// Add the decimal to the display screen if valid, when button is clicked.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnDecimalButtonClick(object sender, EventArgs eventArgs)
        {
            if (!(_displayTextBox.Text.Contains('.')))
            {
                this._displayTextBox.Text = _controller.AddDecimalToDisplay(_displayTextBox.Text, (sender as C1Button).Tag.ToString());
            }
        }

        /// <summary>
        /// Removes the last entered character from the display screen, when button is clicked.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnBackspaceButtonClick(object sender, EventArgs eventArgs)
        {
            this._displayTextBox.Text = _controller.HandleBackspaceOperation(_displayTextBox.Text);
            
        }

        /// <summary>
        /// Removes the text from the display screen, when button is clicked.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnClearDisplayButtonClick(object sender, EventArgs eventArgs)
        {
            if ((sender as C1Button).Tag.ToString() == Resources.StringResource.ButtonCancelContent)
            {
                this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
                this._displayLabel.Text = Resources.StringResource.LabelInitialContent;
            }
            else if ((sender as C1Button).Tag.ToString() == Resources.StringResource.ButtonCancelEntryContent)
            {
                this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
            }
        }

        /// <summary>
        /// Adds the operator to the operand present as input and asks for next user input
        /// in order to proceed with the calculation.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnBinaryOperatorButtonClick(object sender, EventArgs eventArgs)
        {
            decimal operandFirst;
            decimal operandSecond;

            try
            {
                // Display label data is empty and display textbox contains some valid decimal.
                if (this._displayLabel.Text == Resources.StringResource.LabelInitialContent && Decimal.TryParse(this._displayTextBox.Text, out operandFirst))
                {
                    this._displayLabel.Text = operandFirst.ToString() + " " + (sender as C1Button).Tag.ToString();
                }
                // Display label data contains a valid decimal without an operator and display textbox is empty.
                else if (Decimal.TryParse(this._displayLabel.Text, out operandFirst) && this._displayTextBox.Text == Resources.StringResource.TextboxInitialContent && this._displayLabel.Text != Resources.StringResource.LabelInitialContent)
                {
                    if (this._displayLabel.Text[this._displayLabel.Text.Length - 1] == '-')
                    {
                        operandFirst = operandFirst * -1;
                    }
                    this._displayLabel.Text = operandFirst.ToString() + " " + (sender as C1Button).Tag.ToString();
                }
                // Display label data contains a valid decimal without an operator and display textbox also contains a valid decimal.
                else if (Decimal.TryParse(this._displayLabel.Text, out operandFirst) && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '-' && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '+' && Decimal.TryParse(this._displayTextBox.Text, out operandFirst) && this._displayLabel.Text != Resources.StringResource.LabelInitialContent)
                {
                    this._displayLabel.Text = operandFirst.ToString() + " " + (sender as C1Button).Tag.ToString();
                }
                // Display label data contains a valid decimal with an operator and display textbox also contains  a valid decimal.
                else if (Decimal.TryParse(this._displayLabel.Text.Substring(0, this._displayLabel.Text.Length - 2), out operandFirst) && Decimal.TryParse(this._displayTextBox.Text, out operandSecond) && this._displayLabel.Text != Resources.StringResource.LabelInitialContent)
                {
                    this._displayLabel.Text = _controller.GetCalculationResult(operandFirst, operandSecond, this._displayLabel.Text.Substring(this._displayLabel.Text.Length - 1, 1)) + " " + (sender as C1Button).Tag.ToString();
                }
                this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
            }
            // Handling exceptions.
            catch(DivideByZeroException ex)
            {
                MessageBox.Show(ex.Message, Resources.StringResource.ErrorMessageBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Resources.StringResource.ErrorMessageBoxTitle , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Performs the unary operation on the user input.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnUnaryOperatorButtonClick(object sender, EventArgs eventArgs)
        {
            decimal newOperand;
            decimal previousOperand;

            if (this._displayLabel.Text == Resources.StringResource.LabelInitialContent && Decimal.TryParse(this._displayTextBox.Text, out newOperand)) 
            {
                this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as C1Button).Tag.ToString());
            }
            else if(this._displayLabel.Text != Resources.StringResource.LabelInitialContent && this._displayTextBox.Text == Resources.StringResource.TextboxInitialContent && Decimal.TryParse(this._displayLabel.Text, out newOperand))
            {
                if (this._displayLabel.Text[this._displayLabel.Text.Length - 1] == '-')
                {
                    newOperand = newOperand * -1;
                }
                this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as C1Button).Tag.ToString());
            }
            else if (this._displayLabel.Text != Resources.StringResource.LabelInitialContent && this._displayTextBox.Text != Resources.StringResource.TextboxInitialContent && Decimal.TryParse(this._displayLabel.Text, out newOperand))
            {
                if(Decimal.TryParse(this._displayLabel.Text, out previousOperand) && Decimal.TryParse(this._displayTextBox.Text, out newOperand) && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '+' && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '-')
                {
                        this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as C1Button).Tag.ToString());
                }
                else if (Decimal.TryParse(this._displayLabel.Text.Substring(0, this._displayLabel.Text.Length - 2), out previousOperand) && Decimal.TryParse(this._displayTextBox.Text, out newOperand))
                {
                    decimal result;

                    if(Decimal.TryParse(_controller.GetCalculationResult(previousOperand, newOperand, this._displayLabel.Text.Substring(this._displayLabel.Text.Length - 1, 1)), out result))
                    {
                        this._displayLabel.Text = _controller.GetCalculationResult(result, (sender as C1Button).Tag.ToString());
                    }
                }
            }
            else if(Decimal.TryParse(this._displayLabel.Text.Substring(0 , this._displayLabel.Text.Length - 2), out newOperand) && this._displayLabel.Text != Resources.StringResource.LabelInitialContent && this._displayTextBox.Text == Resources.StringResource.TextboxInitialContent)
            {
                this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as C1Button).Tag.ToString());
            }
            this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
        }

        /// <summary>
        /// Display the result on the display screen.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnEquateButtonClick(object sender, EventArgs eventArgs)
        {
            decimal newOperand;
            decimal previousOperand;

            try
            { 
                // Display label data is empty and display textbox contains some valid decimal.
                if (this._displayLabel.Text == Resources.StringResource.LabelInitialContent && Decimal.TryParse(this._displayTextBox.Text, out newOperand))
                {
                    this._displayLabel.Text = this._displayTextBox.Text;
                }
                // Display label data contains a valid decimal without any operator and display textbox also contains a valid decimal.
                else if (Decimal.TryParse(this._displayLabel.Text, out previousOperand) && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '-' && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '+' && Decimal.TryParse(this._displayTextBox.Text, out newOperand) && this._displayTextBox.Text != Resources.StringResource.TextboxInitialContent)
                {
                    this._displayLabel.Text = this._displayTextBox.Text;
                }
                // Display label data contains a valid decimal with an operator and display textbox also contains a valid decimal.
                else if (Decimal.TryParse(this._displayLabel.Text.Substring(0, this._displayLabel.Text.Length - 2), out previousOperand) && Decimal.TryParse(this._displayTextBox.Text, out newOperand))
                {
                    this._displayLabel.Text = _controller.GetCalculationResult(previousOperand, newOperand, this._displayLabel.Text.Substring(this._displayLabel.Text.Length - 1, 1));
                }
                this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
            }
            // Handling exceptions.
            catch (DivideByZeroException ex)
            {
                MessageBox.Show(ex.Message, Resources.StringResource.ErrorMessageBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Resources.StringResource.ErrorMessageBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Performs the unary operation on the user input.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnUnaryOperatorSplitButtonItemClick(object sender, EventArgs eventArgs)
        {
            decimal newOperand;
            decimal previousOperand;

            try
            {
                if (this._displayLabel.Text == Resources.StringResource.LabelInitialContent && Decimal.TryParse(this._displayTextBox.Text, out newOperand))
                {
                    this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as SplitButtonItem).Tag.ToString());
                }
                else if (this._displayLabel.Text != Resources.StringResource.LabelInitialContent && this._displayTextBox.Text == Resources.StringResource.TextboxInitialContent && Decimal.TryParse(this._displayLabel.Text, out newOperand))
                {
                    if (this._displayLabel.Text[this._displayLabel.Text.Length - 1] == '-')
                    {
                        newOperand = newOperand * -1;
                    }
                    this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as SplitButtonItem).Tag.ToString());
                }
                else if (this._displayLabel.Text != Resources.StringResource.LabelInitialContent && this._displayTextBox.Text != Resources.StringResource.TextboxInitialContent && Decimal.TryParse(this._displayLabel.Text, out newOperand))
                {
                    if (Decimal.TryParse(this._displayLabel.Text, out previousOperand) && Decimal.TryParse(this._displayTextBox.Text, out newOperand) && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '+' && this._displayLabel.Text[this._displayLabel.Text.Length - 1] != '-')
                    {
                        this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as SplitButtonItem).Tag.ToString());
                    }
                    else if (Decimal.TryParse(this._displayLabel.Text.Substring(0, this._displayLabel.Text.Length - 2), out previousOperand) && Decimal.TryParse(this._displayTextBox.Text, out newOperand))
                    {
                        decimal result;

                        if (Decimal.TryParse(_controller.GetCalculationResult(previousOperand, newOperand, this._displayLabel.Text.Substring(this._displayLabel.Text.Length - 1, 1)), out result))
                        {
                            this._displayLabel.Text = _controller.GetCalculationResult(result, (sender as SplitButtonItem).Tag.ToString());
                        }
                    }
                }
                else if (Decimal.TryParse(this._displayLabel.Text.Substring(0, this._displayLabel.Text.Length - 2), out newOperand) && this._displayLabel.Text != Resources.StringResource.LabelInitialContent && this._displayTextBox.Text == Resources.StringResource.TextboxInitialContent)
                {
                    this._displayLabel.Text = _controller.GetCalculationResult(newOperand, (sender as SplitButtonItem).Tag.ToString());
                }
                this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, Resources.StringResource.ErrorMessageBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Performs memory operations according to user's input.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnMemoryButtonClick(object sender, EventArgs eventArgs)
        {
            decimal valueOnDisplay;
            if((sender as C1Button).Tag.ToString() == Resources.StringResource.ButtonMemoryReadContent)
            {
                this._displayTextBox.Text = _controller.GetMemoryValue();
            }
            else if(Decimal.TryParse(this._displayTextBox.Text, out valueOnDisplay))
            {
                _controller.HandleMemoryOperations(valueOnDisplay, (sender as C1Button).Tag.ToString());
            }
        }

        /// <summary>
        /// Shows tooltip whenever user right clicks on the sender object.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="mouseEventArgs">Hold event specific message</param>
        private void OnControlsRightMouseButtonClick(object sender, MouseEventArgs mouseEventArgs)
        {
            if (mouseEventArgs.Button == MouseButtons.Right)
            {
                _controlToolTip.Show(_buttonDictionary[(sender as C1Button)].ToolTipContent + (sender as C1Button).Tag.ToString(), (sender as C1Button));
            }
        }

        #endregion

        #region Menu Strip events

        /// <summary>
        /// Copies the selected data the clipboard.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnCopyCommandClick(object sender, EventArgs eventArgs)
        {
            _displayTextBox.Copy();
        }

        /// <summary>
        /// Paste the data, present on the clipboard, to the display screen. 
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnPasteCommandClick(object sender, EventArgs eventArgs)
        {
            if ((Clipboard.GetText().Contains('.') && _displayTextBox.Text.Contains('.')) || (Clipboard.GetText().Contains('-') && _displayTextBox.Text.Contains('-')))
            {
                MessageBox.Show(Resources.StringResource.PasteCommandErrorMessage, Resources.StringResource.ErrorMessageBoxTitle, MessageBoxButtons.OK);
            }
            else
            {
                _displayTextBox.Paste();
            }
        }

        /// <summary>
        /// Opens the 'About' form. 
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnAboutCommandClick(object sender, EventArgs eventArgs)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }

        /// <summary>
        /// Exits the application after user's confirmation.
        /// </summary>
        /// <param name="sender">Control that raises the event</param>
        /// <param name="eventArgs">Hold event specific message</param>
        private void OnExitCommandClick(object sender, EventArgs eventArgs)
        {
            if (MessageBox.Show(Resources.StringResource.ExitCommandMessage, Resources.StringResource.ConfirmationMessageBoxTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        #endregion

        #region Layout Properties

        /// <summary>
        /// Function to create basic grid layout for the calculator User Interface. 
        /// </summary>
        private void CreateBasicLayout()
        {

            // 
            // tableLayoutPanelCalculator
            // 
            this._tableLayoutPanelCalculator.ColumnCount = 1;
            this._tableLayoutPanelCalculator.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this._tableLayoutPanelCalculator.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tableLayoutPanelCalculator.Location = new System.Drawing.Point(0, 0);
            this._tableLayoutPanelCalculator.Name = "tableLayoutPanelCalculator";
            this._tableLayoutPanelCalculator.RowCount = 5;
            this._tableLayoutPanelCalculator.RowStyles.Add(new RowStyle(SizeType.Percent, 7F));
            this._tableLayoutPanelCalculator.RowStyles.Add(new RowStyle(SizeType.Percent, 12F));
            this._tableLayoutPanelCalculator.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            this._tableLayoutPanelCalculator.RowStyles.Add(new RowStyle(SizeType.Percent, 6F));
            this._tableLayoutPanelCalculator.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));

            // 
            // tableLayoutPanelKeypad
            // 
            this._tableLayoutPanelKeypad.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tableLayoutPanelKeypad.Name = "tableLayoutPanelKeypad";
            this._tableLayoutPanelKeypad.RowCount = 7;
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this._tableLayoutPanelKeypad.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this._tableLayoutPanelKeypad.ColumnCount = 4;
            this._tableLayoutPanelKeypad.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this._tableLayoutPanelKeypad.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this._tableLayoutPanelKeypad.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this._tableLayoutPanelKeypad.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));

            this._tableLayoutPanelCalculator.Controls.Add(this._tableLayoutPanelKeypad, 0, 4);

        }

        /// <summary>
        /// Function to create keypad of the calculator.
        /// </summary>
        private void CreateKeypad()
        {
            foreach (var buttonItem in _buttonDictionary)
            {
                SetButtonProperties(buttonItem.Key, buttonItem.Value);
            }

            foreach (var splitButtonItem in _splitButtonItemDictionary)
            {
                SetSplitButtonItemProperties(splitButtonItem.Key, splitButtonItem.Value);
            }

            //
            // _flowLayoutSplitButtonsPanel
            //
            this._flowLayoutSplitButtonsPanel.Dock = DockStyle.Fill;
            this._flowLayoutSplitButtonsPanel.FlowDirection = FlowDirection.RightToLeft;

            //
            // _buttonTrigonometricFunction
            //
            this._splitButtonTrigonometricFunction.Text = Resources.StringResource.ButtonTrigonometricFunctionContent;
            this._splitButtonTrigonometricFunction.Font = new Font("Calibri", 9F, FontStyle.Bold);
            this._splitButtonTrigonometricFunction.Width = 120;

            //
            // _buttonLogarithmic
            //
            this._splitButtonLogarithmic.Text = Resources.StringResource.ButtonLogarithmicContent;
            this._splitButtonLogarithmic.Font = new Font("Calibri", 9F, FontStyle.Bold);
            this._splitButtonLogarithmic.Width = 120;

            //
            // Creating controls hierarcy
            //
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonZero, 1, 6);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonOne, 0, 5);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonTwo, 1, 5);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonThree, 2, 5);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonFour, 0, 4);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonFive, 1, 4);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonSix, 2, 4);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonSeven, 0, 3);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonEight, 1, 3);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonNine, 2, 3);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonDecimal, 2, 6);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonSign, 0, 6);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonAdd, 3, 5);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonSubtract, 3, 4);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonMultiply, 3, 3);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonDivide, 3, 2);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonEquate, 3, 6);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonPercentage, 2, 2);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonBackspace, 3, 0);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonCancel, 2, 0);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonCancelEntry, 1, 0);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonMemoryStore, 0, 1);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonMemoryRead, 1, 1);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonMemoryAdd, 2, 1);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonMemoryDelete, 3, 1);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonMemoryClear, 0, 0);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonSquare, 0, 2);
            this._tableLayoutPanelKeypad.Controls.Add(this._buttonReciprocal, 1, 2);
            this._tableLayoutPanelCalculator.Controls.Add(this._flowLayoutSplitButtonsPanel, 0, 3);
            this._splitButtonTrigonometricFunction.Items.Add(this._buttonItemSin);
            this._splitButtonTrigonometricFunction.Items.Add(this._buttonItemCos);
            this._splitButtonTrigonometricFunction.Items.Add(this._buttonItemTan);
            this._splitButtonTrigonometricFunction.Items.Add(this._buttonItemCot);
            this._splitButtonTrigonometricFunction.Items.Add(this._buttonItemSec);
            this._splitButtonTrigonometricFunction.Items.Add(this._buttonItemCosec);
            this._flowLayoutSplitButtonsPanel.Controls.Add(this._splitButtonTrigonometricFunction);
            this._flowLayoutSplitButtonsPanel.Controls.Add(this._splitButtonLogarithmic);
            this._splitButtonLogarithmic.Items.Add(this._buttonItemLoge);
            this._splitButtonLogarithmic.Items.Add(this._buttonItemLog10);
        }

        /// <summary>
        /// Function to create display screen of the calculator.
        /// </summary>
        private void CreateDisplay()
        {
            //
            // _displayLabel
            //
            this._displayLabel.ForeColor = Color.Gray;
            this._displayLabel.Font = new Font("Calibri", 12F, FontStyle.Bold);
            this._displayLabel.Text = Resources.StringResource.LabelInitialContent;
            this._displayLabel.Dock = DockStyle.Fill;
            this._displayLabel.TextAlign = ContentAlignment.BottomRight;

            //
            // _displayTextBox
            //
            this._displayTextBox.Dock = DockStyle.Fill;
            this._displayTextBox.Text = Resources.StringResource.TextboxInitialContent;
            this._displayTextBox.TextAlign = HorizontalAlignment.Right;
            this._displayTextBox.Font = new Font("Calibri", 18F, FontStyle.Bold);
            this._displayTextBox.KeyPress += new KeyPressEventHandler(OnDisplayTextBoxKeyPress);
            this._displayTextBox.Enter += new EventHandler(OnDisplayTextBoxEnter);
            this._displayTextBox.Leave += new EventHandler(OnDisplayTextBoxLeave);

            // Adding controls to the '_tableLayoutPanelCalculator.Controls'.
            this._tableLayoutPanelCalculator.Controls.Add(this._displayLabel, 0, 1);
            this._tableLayoutPanelCalculator.Controls.Add(this._displayTextBox, 0, 2);

        }

        /// <summary>
        /// Function to create menu strip of the calculator.
        /// </summary>
        private void CreateMenuStrip()
        {
            this._tableLayoutPanelCalculator.Controls.Add(this._mainMenu, 0, 0);

            // Edit Command
            _commandEdit = (C1CommandMenu)(this._mainMenu.CommandHolder).CreateCommand(typeof(C1CommandMenu));
            _commandEdit.Text = Resources.StringResource.EditMenuCommandText;

            // Copy Command
            _commandCopy = (this._mainMenu.CommandHolder).CreateCommand();
            _commandCopy.Text = Resources.StringResource.CopyMenuCommandText;
            _commandCopy.Shortcut = Shortcut.CtrlC;
            _commandCopy.Click += new ClickEventHandler(OnCopyCommandClick);

            // Paste Command
            _commandPaste = (this._mainMenu.CommandHolder).CreateCommand();
            _commandPaste.Text = Resources.StringResource.PasteMenuCommandText;
            _commandPaste.Shortcut = Shortcut.CtrlV;
            _commandPaste.Click += new ClickEventHandler(OnPasteCommandClick);

            // Exit Command
            _commandExit = (C1CommandMenu)(this._mainMenu.CommandHolder).CreateCommand(typeof(C1CommandMenu));
            _commandExit.Text = Resources.StringResource.ExitMenuCommandText;
            _commandExit.Click += new ClickEventHandler(OnExitCommandClick);

            // Help Command
            _commandHelp = (C1CommandMenu)(this._mainMenu.CommandHolder).CreateCommand(typeof(C1CommandMenu));
            _commandHelp.Text = Resources.StringResource.HelpMenuCommandText;

            // About Command
            _commandAbout = (this._mainMenu.CommandHolder).CreateCommand();
            _commandAbout.Text = Resources.StringResource.AboutMenuCommandText;
            _commandAbout.Shortcut = Shortcut.F8;
            _commandAbout.Click += new ClickEventHandler(OnAboutCommandClick);


            // Linking menu commands
            _mainMenu.CommandLinks.Add(new C1CommandLink(_commandEdit));
            _mainMenu.CommandLinks.Add(new C1CommandLink(_commandExit));
            _mainMenu.CommandLinks.Add(new C1CommandLink(_commandHelp));
            _commandEdit.CommandLinks.Add(new C1CommandLink(_commandCopy));
            _commandEdit.CommandLinks.Add(new C1CommandLink(_commandPaste));
            _commandHelp.CommandLinks.Add(new C1CommandLink(_commandAbout));

        }

        /// <summary>
        /// Sets the properties of the C1Button using ButtonLayout class.
        /// </summary>
        /// <param name="button">C1Button type object</param>
        /// <param name="buttonLayout">ButtonLayout type object</param>
        private void SetButtonProperties(C1Button button, ButtonLayout buttonLayout)
        { 
            button.Dock = DockStyle.Fill;
            button.Text = buttonLayout.ButtonContent;
            button.Font = new Font("Calibri", buttonLayout.ButtonFontSize, FontStyle.Bold);
            button.Tag = buttonLayout.ButtonContent;
            button.Click += buttonLayout.ButtonClickEventHandler;
            button.MouseUp += buttonLayout.ButtonMouseRightClickEventHandler;
        }

        /// <summary>
        /// Sets the properties of the SplitButtonItem using SplitButtonItemLayout class.
        /// </summary>
        /// <param name="splitButtonItem">SplitButtonItem type object</param>
        /// <param name="splitButtonItemLayout">SplitButtonItemLayout type object</param>
        private void SetSplitButtonItemProperties(SplitButtonItem splitButtonItem, SplitButtonItemLayout splitButtonItemLayout)
        {
            splitButtonItem.Text = splitButtonItemLayout.SplitButtonItemContent;
            splitButtonItem.Tag = splitButtonItemLayout.SplitButtonItemContent;
            splitButtonItem.Click += splitButtonItemLayout.SplitButtonItemEventHandler;
        }

        #endregion
    }
}