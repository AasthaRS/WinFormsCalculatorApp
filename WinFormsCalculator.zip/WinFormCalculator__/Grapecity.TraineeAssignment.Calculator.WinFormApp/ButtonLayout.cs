﻿namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    /// <summary>
    /// 
    /// 'ButtonLayout' class contains the following properties:
    ///     
    ///     ButtonContent : To store the content associated with the button.
    ///     ButtonSize : To store the font size of the button content.
    ///     ButtonClickEventHandler : To store EventHandler for the button.
    ///     ButtonMouseRightClickEventHandler : To store MouseEventHandler for the button.
    ///     ToolTipContent : To store the tool tip content for the button.
    ///     
    /// 'ButtonLayout' class contains a constructor to set value of the 'ToolTipContent' field.
    /// 
    /// </summary>
    public class ButtonLayout
    {
        public string ButtonContent {get; init;}
        public float ButtonFontSize { get; init; }
        public EventHandler ButtonClickEventHandler { get; init; }
        public MouseEventHandler ButtonMouseRightClickEventHandler { get; init; }
        public string ToolTipContent { get; }
        
        // Constructor to set properties of the fields.
        public ButtonLayout(ToolTipLayout toolTipLayout)
        {
            this.ToolTipContent = Resources.StringResource.TooltipFunctionalityHeader + " " + toolTipLayout.ToolTipFunctionality + "\n" + Resources.StringResource.TooltipUsageHeader
                + toolTipLayout.ToolTipUsage + "\n" + Resources.StringResource.TooltipKeyboardEquivalentHeader + " " + toolTipLayout.ToolTipKeyboardEquivalent + " ";
        }

    }

}
