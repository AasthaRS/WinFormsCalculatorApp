﻿namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    /// <summary>
    /// 
    /// 'SplitButtonItemLayout' class contains the following properties:
    ///     
    ///     SplitButtonItemContent : To store the content associated with the splitbutton item.
    ///     SplitButtonItemEventHandler : To store EventHandler for the splitbutton item.
    ///     
    /// </summary>
    public class SplitButtonItemLayout
    {
        public string SplitButtonItemContent { get; init; }
        public EventHandler SplitButtonItemEventHandler { get; init; }

    }
}
