﻿namespace Grapecity.TraineeAssignment.Calculator.WinFormApp
{
    /// <summary>
    /// 'CalculatorController' class is an interface between the Windows Form
    /// application named 'CalculationForm' and the class library used by this 
    /// application.
    /// </summary>
    public class CalculatorController
    {
        private OperationsManager _operationsManager;
        private static decimal _memoryValue;

        /// <summary>
        /// Constructor to create instance of 'OperationsManager' class.
        /// </summary>
        public CalculatorController()
        {
            _operationsManager = new OperationsManager();
        }

        /// <summary>
        /// Function to add numeric value to the display.
        /// </summary>
        /// <param name="existingString"></param>
        /// <param name="newString"></param>
        /// <returns>Final string to be displayed on the screen.</returns>
        public string AddNumberToDisplay(string existingString, string newString)
        {
            if (existingString == Resources.StringResource.TextboxInitialContent)
            {
                existingString = newString;
            }
            else
            {
                existingString += newString;
            }
            return existingString;
        }

        /// <summary>
        /// Function to add decimal point to the display.
        /// </summary>
        /// <param name="existingString"></param>
        /// <param name="newString"></param>
        /// <returns>Final string to be displayed on the screen.</returns>
        public string AddDecimalToDisplay(string existingString, string newString)
        {
            if (!(existingString.Contains(newString)))
            {
                existingString = existingString + newString;
            }
            return existingString;
        }

        /// <summary>
        /// Function to handle backspace operation.
        /// </summary>
        /// <param name="displayString"></param>
        /// <returns>Final string to be displayed on the screen.</returns>
        public string HandleBackspaceOperation(string displayString)
        {
            if((displayString != Resources.StringResource.TextboxInitialContent) && (displayString.Length > 1))
            {
                displayString = displayString.Substring(0, displayString.Length - 1);
            }
            else
            {
                displayString = Resources.StringResource.TextboxInitialContent;
            }
            return displayString;
        }

        /// <summary>
        /// Function to perform calculations for binary operations.
        /// </summary>
        /// <param name="operand1"></param>
        /// <param name="operand2"></param>
        /// <param name="_operator"></param>
        /// <returns>Result of the calculation to be displayed on the screen.</returns>
        /// <exception cref="DivideByZeroException"></exception>
        public string GetCalculationResult(decimal operand1, decimal operand2, string _operator)
        {
            decimal[] operands = { operand1, operand2 };
            if(operand2 == 0 && _operator == Resources.StringResource.ButtonDivideContent)
            {
                throw new DivideByZeroException(Resources.StringResource.DivisionByZeroExceptionMessage);
            }
            return (_operationsManager.GetResult(operands, _operator)).ToString();
        }

        /// <summary>
        /// Function to perform calculations for unary operations.
        /// </summary>
        /// <param name="operand"></param>
        /// <param name="_operator"></param>
        /// <returns>Result of the calculation to be displayed on the screen.</returns>
        /// <exception cref="OverflowException"></exception>
        public string GetCalculationResult(decimal operand, string _operator)
        {
            decimal[] operands = { operand };
            if(operand == 0 && _operator == Resources.StringResource.ButtonItemLogeContent)
            {
                throw new OverflowException(Resources.StringResource.LogOverflowExceptionMessage);
            }
            return (_operationsManager.GetResult(operands, _operator)).ToString();
        }

        /// <summary>
        /// Function to handle the memory operations of the calculator.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="operation"></param>
        public void HandleMemoryOperations(decimal value, string operation)
        {
            if(operation == Resources.StringResource.ButtonMemoryStoreContent)
            {
                _memoryValue = value;
            }
            else if(operation == Resources.StringResource.ButtonMemoryAddContent)
            {
                _memoryValue += value;
            }
            else if(operation == Resources.StringResource.ButtonMemoryDeleteContent)
            {
                _memoryValue -= value;
            }
            else if(operation == Resources.StringResource.ButtonMemoryClearContent)
            {
                _memoryValue = 0;
            }
        }

        /// <summary>
        /// Function to handle keyboard inputs for the textbox.
        /// </summary>
        /// <param name="displayString"></param>
        /// <param name="keyPressEventArgs"></param>
        /// <returns>Boolean result if key press event is to be handled or not.</returns>
        public bool HandleKeyInputForDisplayTextbox(string displayString, KeyPressEventArgs keyPressEventArgs)
        {
            if (keyPressEventArgs.KeyChar == '-' && displayString.Length == 0)
            {
                return false;
            }
            else if ((keyPressEventArgs.KeyChar == '.') && !(displayString.Contains('.')))
            {
                return false;
            }
            else if (!(char.IsDigit(keyPressEventArgs.KeyChar)) && !(char.IsControl(keyPressEventArgs.KeyChar)))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Function to return the current value that is stored as memory value.
        /// </summary>
        /// <returns>Value stored in '_memoryValue'.</returns>
        public string GetMemoryValue()
        {
            return _memoryValue.ToString();
        }
    }
}
