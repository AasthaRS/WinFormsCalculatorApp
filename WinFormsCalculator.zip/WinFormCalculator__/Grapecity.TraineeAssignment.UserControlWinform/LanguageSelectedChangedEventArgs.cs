﻿namespace Grapecity.TraineeAssignment.UserControlWinform
{
    public class LanguageSelectedChangedEventArgs : EventArgs
    {
        public string SelectedLanguage
        {
            get; init;
        }
    }
}
