﻿namespace Grapecity.TraineeAssignment.UserControlWinform
{
    public partial class LanguagePickerUserControl : UserControl
    {

        private static string _languageSelected;
        public event EventHandler<LanguageSelectedChangedEventArgs> LanguageChanged;

        public LanguagePickerUserControl()
        {
            InitializeComponent();
        }

        public static string LanguageSelected
        {
            get { return _languageSelected; }
        }

        protected virtual void OnLanguageChanged(object sender, LanguageSelectedChangedEventArgs eventArgs)
        {
            if (LanguageChanged != null)
            {
                LanguageChanged(this, eventArgs);
            }
        }

        public void OnApplyButtonClick(object sender, EventArgs eventArgs)
        {
             _languageSelected = _languageComboBox.SelectedItem.ToString();
            LanguageSelectedChangedEventArgs languageSelectedChangedEventArgs = new LanguageSelectedChangedEventArgs() { SelectedLanguage = _languageSelected};
            MessageBox.Show(Resources.StringResource.SetLanguageMessage + _languageSelected, Resources.StringResource.Information_Message, MessageBoxButtons.OK, MessageBoxIcon.Information);
            OnLanguageChanged(sender, languageSelectedChangedEventArgs);
        }
    }
}