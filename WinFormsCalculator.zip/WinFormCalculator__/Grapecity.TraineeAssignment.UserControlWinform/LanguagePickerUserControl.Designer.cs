﻿namespace Grapecity.TraineeAssignment.UserControlWinform
{
    partial class LanguagePickerUserControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._selectLanguageLabel = new System.Windows.Forms.Label();
            this._languageComboBox = new System.Windows.Forms.ComboBox();
            this._applyButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // _selectLanguageLabel
            // 
            this._selectLanguageLabel.AutoSize = true;
            this._selectLanguageLabel.Location = new System.Drawing.Point(15, 30);
            this._selectLanguageLabel.Name = "_selectLanguageLabel";
            this._selectLanguageLabel.Size = new System.Drawing.Size(111, 15);
            this._selectLanguageLabel.TabIndex = 0;
            this._selectLanguageLabel.Text = "Choose a language:";
            // 
            // _languageComboBox
            // 
            this._languageComboBox.FormattingEnabled = true;
            this._languageComboBox.Items.AddRange(new object[] {
            "English",
            "Hindi",
            "French",
            "German",
            "Spanish",
            "Japanese",
            "Arabic"});
            this._languageComboBox.Location = new System.Drawing.Point(144, 27);
            this._languageComboBox.MaxDropDownItems = 3;
            this._languageComboBox.Name = "_languageComboBox";
            this._languageComboBox.Size = new System.Drawing.Size(121, 23);
            this._languageComboBox.SelectedIndex = 0;
            this._languageComboBox.TabIndex = 1;
            this._languageComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            // 
            // _applyButton
            // 
            this._applyButton.Location = new System.Drawing.Point(97, 71);
            this._applyButton.Name = "_applyButton";
            this._applyButton.Size = new System.Drawing.Size(75, 23);
            this._applyButton.TabIndex = 2;
            this._applyButton.Text = "Apply";
            this._applyButton.UseVisualStyleBackColor = true;
            this._applyButton.Click += new System.EventHandler(this.OnApplyButtonClick);
            // 
            // LanguagePickerUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this._applyButton);
            this.Controls.Add(this._languageComboBox);
            this.Controls.Add(this._selectLanguageLabel);
            this.Name = "LanguagePickerUserControl";
            this.Size = new System.Drawing.Size(286, 111);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label _selectLanguageLabel;
        private ComboBox _languageComboBox;
        private Button _applyButton;
    }
}